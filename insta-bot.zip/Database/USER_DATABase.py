USERID_FOR_MASSLOOKER = [
    "ilonatoys_ukr",
    "huevyi_dnepr",
    "_iamkaterinaa_",
    "_akktrissa_",
    "kharkov.ua",
    "viktoriia_poledance",
    "pirozabava"
    ]

USERID_FOR_FOLLOWBOT2 = [
    "obuv_dnepr_skorpion",
    "obuvshopua",
    "obuv_ukraine_ua",
    "luxshop_ukr",
    "bomond.in.ua",
    "shoes4you.ua",
    "shoes_lux_ukraine",
    "obuva4e4ka",
    "detskaia1813",
    "rahul_shrimali_officialdneprovskiy_bukin"
    ]